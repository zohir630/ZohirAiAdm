package com.zohirai.admin;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageMetadata;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Zohirola Admin - sends in-app updates to the user app (com.zohirola.app).
 *
 * Writes Realtime Database node /app_update:
 *   versionCode (number), versionName, apkUrl (https), notes, force, enabled, updatedAt
 * The user app reads the same node (UpdateManager) and forces the install.
 */
public class MainActivity extends Activity {

    /** The user app this admin controls. */
    private static final String TARGET_PKG = "com.zohirola.app";
    private static final String NODE = "app_update";
    private static final int REQ_PICK_APK = 41;

    private static final int INK = Color.parseColor("#111111");
    private static final int MUTED = Color.parseColor("#6B6B6B");
    private static final int BG = Color.parseColor("#F5F4F0");
    private static final int CARD = Color.WHITE;
    private static final int LINE = Color.parseColor("#E2E0DA");
    private static final int RED = Color.parseColor("#B3261E");
    private static final int GREEN = Color.parseColor("#1B7A3E");

    private FrameLayout root;
    private FirebaseAuth auth;
    private DatabaseReference ref;
    private ValueEventListener liveListener;

    // dashboard widgets
    private TextView liveText;
    private EditText etCode, etName, etUrl, etNotes;
    private Switch swForce, swEnabled;
    private TextView pickInfo, status;
    private ProgressBar bar;
    private Button btnPublish, btnPick;

    // state
    private File pickedApk;
    private long pickedCode;
    private String pickedName = "";
    private long publishedCode = 0;
    private boolean busy;

    // =========================================================================
    // lifecycle
    // =========================================================================

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        auth = FirebaseAuth.getInstance();
        ref = FirebaseDatabase.getInstance().getReference(NODE);

        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        setContentView(root);

        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(BG);
            getWindow().setNavigationBarColor(BG);
        }
        if (Build.VERSION.SDK_INT >= 23) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }

        if (auth.getCurrentUser() != null) showDashboard();
        else showLogin();
    }

    @Override
    protected void onDestroy() {
        detachLive();
        super.onDestroy();
    }

    // =========================================================================
    // login
    // =========================================================================

    private void showLogin() {
        detachLive();
        root.removeAllViews();

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_VERTICAL);
        col.setPadding(dp(28), dp(28), dp(28), dp(28));

        TextView t = text("Zohirola Admin", 28, INK, true);
        col.addView(t);
        TextView s = text("এডমিন অ্যাকাউন্ট দিয়ে লগইন করুন", 14.5f, MUTED, false);
        col.addView(s, lp(-1, -2, 6, 0));

        final EditText email = field("ইমেইল", InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        col.addView(email, lp(-1, dp(52), 26, 0));
        final EditText pass = field("পাসওয়ার্ড", InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        col.addView(pass, lp(-1, dp(52), 12, 0));

        final TextView err = text("", 13.5f, RED, false);
        col.addView(err, lp(-1, -2, 10, 0));

        final Button go = button("লগইন", true);
        col.addView(go, lp(-1, dp(52), 16, 0));

        go.setOnClickListener(v -> {
            String e = email.getText().toString().trim();
            String p = pass.getText().toString();
            if (e.isEmpty() || p.isEmpty()) {
                err.setText("ইমেইল ও পাসওয়ার্ড দিন।");
                return;
            }
            err.setText("");
            go.setEnabled(false);
            go.setText("অপেক্ষা করুন…");
            auth.signInWithEmailAndPassword(e, p).addOnCompleteListener(task -> {
                go.setEnabled(true);
                go.setText("লগইন");
                if (task.isSuccessful()) {
                    showDashboard();
                } else {
                    err.setText("লগইন হয়নি। ইমেইল/পাসওয়ার্ড ও ইন্টারনেট দেখুন।");
                }
            });
        });

        root.addView(col, new FrameLayout.LayoutParams(-1, -1));
    }

    // =========================================================================
    // dashboard
    // =========================================================================

    private void showDashboard() {
        root.removeAllViews();
        pickedApk = null;
        pickedCode = 0;
        pickedName = "";

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(22), dp(18), dp(40));
        sv.addView(col, new ViewGroup.LayoutParams(-1, -2));

        // ---- header ---------------------------------------------------------
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(text("Zohirola Admin", 24, INK, true));
        FirebaseUser u = auth.getCurrentUser();
        String who = u != null && u.getEmail() != null ? u.getEmail() : "";
        titles.addView(text(who, 13, MUTED, false), lp(-2, -2, 2, 0));
        head.addView(titles, new LinearLayout.LayoutParams(0, -2, 1f));
        Button out = button("লগআউট", false);
        out.setOnClickListener(v -> {
            auth.signOut();
            showLogin();
        });
        head.addView(out, new LinearLayout.LayoutParams(-2, dp(40)));
        col.addView(head);

        // ---- live card ------------------------------------------------------
        LinearLayout live = card();
        live.addView(text("বর্তমানে প্রকাশিত আপডেট", 15, INK, true));
        liveText = text("লোড হচ্ছে…", 14, MUTED, false);
        liveText.setLineSpacing(0, 1.2f);
        live.addView(liveText, lp(-1, -2, 8, 0));
        Button disable = button("আপডেট বন্ধ করুন", false);
        disable.setOnClickListener(v -> confirmDisable());
        live.addView(disable, lp(-1, dp(44), 14, 0));
        col.addView(live, lp(-1, -2, 18, 0));

        // ---- publish card ---------------------------------------------------
        LinearLayout pub = card();
        pub.addView(text("নতুন আপডেট পাঠান", 15, INK, true));
        pub.addView(text("APK বাছাই করলে ভার্সন নিজে থেকেই পড়া হবে, তারপর Firebase Storage-এ আপলোড হবে। "
                + "অথবা নিচে সরাসরি https লিংক দিন।", 13, MUTED, false), lp(-1, -2, 4, 0));

        btnPick = button("APK ফাইল বাছাই করুন", false);
        btnPick.setOnClickListener(v -> pickApk());
        pub.addView(btnPick, lp(-1, dp(46), 14, 0));
        pickInfo = text("", 13, MUTED, false);
        pub.addView(pickInfo, lp(-1, -2, 6, 0));

        etCode = field("Version code (যেমন 10)", InputType.TYPE_CLASS_NUMBER);
        pub.addView(etCode, lp(-1, dp(50), 14, 0));
        etName = field("Version name (যেমন 10.0)", InputType.TYPE_CLASS_TEXT);
        pub.addView(etName, lp(-1, dp(50), 10, 0));
        etUrl = field("APK লিংক (https://…)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        pub.addView(etUrl, lp(-1, dp(50), 10, 0));
        etNotes = field("কী কী নতুন (ইউজার দেখবে)", InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        etNotes.setMinLines(3);
        etNotes.setGravity(Gravity.TOP | Gravity.START);
        pub.addView(etNotes, lp(-1, -2, 10, 0));

        swForce = new Switch(this);
        swForce.setText("আপডেট না করলে অ্যাপ চলবে না (Force)");
        swForce.setTextColor(INK);
        swForce.setTextSize(14);
        swForce.setChecked(true);
        pub.addView(swForce, lp(-1, -2, 16, 0));
        swEnabled = new Switch(this);
        swEnabled.setText("আপডেট চালু");
        swEnabled.setTextColor(INK);
        swEnabled.setTextSize(14);
        swEnabled.setChecked(true);
        pub.addView(swEnabled, lp(-1, -2, 12, 0));

        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setVisibility(View.GONE);
        pub.addView(bar, lp(-1, dp(6), 16, 0));
        status = text("", 13.5f, MUTED, false);
        pub.addView(status, lp(-1, -2, 8, 0));

        btnPublish = button("আপডেট পাঠান", true);
        btnPublish.setOnClickListener(v -> onPublish());
        pub.addView(btnPublish, lp(-1, dp(52), 14, 0));
        col.addView(pub, lp(-1, -2, 14, 0));

        // ---- UID helper (needed once for the database rules) -------------------
        if (u != null) {
            final String uid = u.getUid();
            TextView uidView = text("আপনার UID (Firebase rules-এ লাগবে): " + uid + "\n(কপি করতে ট্যাপ করুন)",
                    12, MUTED, false);
            uidView.setOnClickListener(v -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("uid", uid));
                toast("UID কপি হয়েছে");
            });
            col.addView(uidView, lp(-1, -2, 18, 0));
        }

        root.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        attachLive();
    }

    // ---- live node ----------------------------------------------------------

    private void attachLive() {
        detachLive();
        liveListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot s) {
                if (liveText == null) return;
                if (!s.exists()) {
                    publishedCode = 0;
                    liveText.setText("এখনো কোনো আপডেট পাঠানো হয়নি।");
                    return;
                }
                publishedCode = asLong(s.child("versionCode").getValue());
                String name = asStr(s.child("versionName").getValue());
                boolean en = !Boolean.FALSE.equals(s.child("enabled").getValue());
                boolean fo = !Boolean.FALSE.equals(s.child("force").getValue());
                String url = asStr(s.child("apkUrl").getValue());
                String notes = asStr(s.child("notes").getValue());
                StringBuilder sb = new StringBuilder();
                sb.append("ভার্সন: ").append(name.isEmpty() ? "-" : name)
                        .append("  (code ").append(publishedCode).append(")\n");
                sb.append("অবস্থা: ").append(en ? "চালু" : "বন্ধ")
                        .append(" • ").append(fo ? "Force" : "ঐচ্ছিক").append("\n");
                sb.append("লিংক: ").append(url.length() > 60 ? url.substring(0, 60) + "…" : url);
                if (!notes.isEmpty()) sb.append("\nনোট: ").append(notes);
                liveText.setText(sb.toString());
                liveText.setTextColor(en ? GREEN : MUTED);
            }

            @Override
            public void onCancelled(DatabaseError e) {
                if (liveText != null) liveText.setText("পড়া যায়নি: " + e.getMessage());
            }
        };
        ref.addValueEventListener(liveListener);
    }

    private void detachLive() {
        if (liveListener != null) {
            try { ref.removeEventListener(liveListener); } catch (Throwable ignored) {}
            liveListener = null;
        }
    }

    // =========================================================================
    // APK pick
    // =========================================================================

    private void pickApk() {
        if (busy) return;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try {
            startActivityForResult(i, REQ_PICK_APK);
        } catch (Throwable t) {
            toast("ফাইল বাছাই খোলা যায়নি");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK_APK || res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        setBusy(true);
        setStatus("APK পড়া হচ্ছে…", MUTED);
        new Thread(() -> {
            File f = new File(getCacheDir(), "picked.apk");
            String error = null;
            PackageInfo pi = null;
            try {
                InputStream in = getContentResolver().openInputStream(uri);
                if (in == null) throw new Exception("open");
                FileOutputStream out = new FileOutputStream(f);
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                out.close();
                in.close();
                pi = getPackageManager().getPackageArchiveInfo(f.getAbsolutePath(), 0);
                if (pi == null) error = "এটা সঠিক APK ফাইল নয়।";
                else if (!TARGET_PKG.equals(pi.packageName))
                    error = "এই APK-র package: " + pi.packageName + "\nহওয়ার কথা: " + TARGET_PKG;
            } catch (Throwable t) {
                error = "ফাইল পড়া যায়নি।";
            }
            final String err = error;
            final PackageInfo info = pi;
            final File file = f;
            runOnUiThread(() -> {
                setBusy(false);
                if (err != null) {
                    pickedApk = null;
                    pickInfo.setText(err);
                    pickInfo.setTextColor(RED);
                    setStatus("", MUTED);
                    file.delete();
                    return;
                }
                pickedApk = file;
                pickedCode = Build.VERSION.SDK_INT >= 28 ? info.getLongVersionCode() : info.versionCode;
                pickedName = info.versionName == null ? "" : info.versionName;
                etCode.setText(String.valueOf(pickedCode));
                etName.setText(pickedName);
                etUrl.setText("");
                pickInfo.setText(String.format(Locale.US, "✓ APK ঠিক আছে — %s (code %d), %.1f MB",
                        pickedName, pickedCode, file.length() / 1048576.0));
                pickInfo.setTextColor(GREEN);
                setStatus("", MUTED);
            });
        }).start();
    }

    // =========================================================================
    // publish
    // =========================================================================

    private void onPublish() {
        if (busy) return;
        final long code = asLong(etCode.getText().toString());
        final String name = etName.getText().toString().trim();
        final String notes = etNotes.getText().toString().trim();
        final String typedUrl = etUrl.getText().toString().trim();

        if (code <= 0) { setStatus("Version code দিন।", RED); return; }
        if (name.isEmpty()) { setStatus("Version name দিন।", RED); return; }
        if (publishedCode > 0 && code < publishedCode) {
            setStatus("Version code (" + code + ") আগের প্রকাশিত (" + publishedCode
                    + ") এর চেয়ে ছোট হতে পারবে না।", RED);
            return;
        }
        if (pickedApk != null && pickedCode != code) {
            setStatus("বাছাই করা APK-র code (" + pickedCode + ") আর লেখা code মিলছে না।", RED);
            return;
        }
        if (pickedApk == null) {
            if (!typedUrl.toLowerCase(Locale.US).startsWith("https://")) {
                setStatus("APK বাছাই করুন অথবা https:// দিয়ে শুরু হওয়া লিংক দিন।", RED);
                return;
            }
        }

        setBusy(true);
        if (pickedApk != null) {
            uploadThenPublish(code, name, notes);
        } else {
            writeNode(code, name, typedUrl, notes);
        }
    }

    private void uploadThenPublish(final long code, final String name, final String notes) {
        final StorageReference sref = FirebaseStorage.getInstance().getReference()
                .child("updates/zohirola-" + code + ".apk");
        StorageMetadata meta = new StorageMetadata.Builder()
                .setContentType("application/vnd.android.package-archive").build();
        bar.setVisibility(View.VISIBLE);
        bar.setProgress(0);
        setStatus("আপলোড হচ্ছে… 0%", MUTED);

        sref.putFile(Uri.fromFile(pickedApk), meta)
                .addOnProgressListener(snap -> {
                    long total = snap.getTotalByteCount();
                    int pct = total > 0 ? (int) (snap.getBytesTransferred() * 100 / total) : 0;
                    bar.setProgress(pct);
                    setStatus("আপলোড হচ্ছে… " + pct + "%", MUTED);
                })
                .addOnSuccessListener(snap -> sref.getDownloadUrl()
                        .addOnSuccessListener(url -> writeNode(code, name, url.toString(), notes))
                        .addOnFailureListener(e -> fail("আপলোড হয়েছে কিন্তু লিংক পাওয়া যায়নি: " + e.getMessage())))
                .addOnFailureListener(e -> fail("আপলোড হয়নি: " + e.getMessage()
                        + "\n(Storage rules/UID ঠিক আছে কি দেখুন, অথবা সরাসরি লিংক ব্যবহার করুন)"));
    }

    private void writeNode(long code, String name, String url, String notes) {
        setStatus("আপডেট প্রকাশ হচ্ছে…", MUTED);
        Map<String, Object> m = new HashMap<>();
        m.put("versionCode", code);
        m.put("versionName", name);
        m.put("apkUrl", url);
        m.put("notes", notes);
        m.put("force", swForce.isChecked());
        m.put("enabled", swEnabled.isChecked());
        m.put("updatedAt", ServerValue.TIMESTAMP);
        ref.setValue(m).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                setBusy(false);
                bar.setVisibility(View.GONE);
                setStatus("✓ আপডেট পাঠানো হয়েছে। ইউজারদের অ্যাপ এখন থেকে আপডেট চাইবে।", GREEN);
                if (pickedApk != null) {
                    pickedApk.delete();
                    pickedApk = null;
                }
                pickInfo.setText("");
            } else {
                Exception e = task.getException();
                String msg = e == null ? "" : String.valueOf(e.getMessage());
                if (msg.toLowerCase(Locale.US).contains("permission")) {
                    fail("লেখার অনুমতি নেই (Permission denied)।");
                    showRulesHelp();
                } else {
                    fail("প্রকাশ হয়নি: " + msg);
                }
            }
        });
    }

    private void confirmDisable() {
        new AlertDialog.Builder(this)
                .setTitle("আপডেট বন্ধ করবেন?")
                .setMessage("ইউজারদের অ্যাপে আর আপডেট স্ক্রিন আসবে না (ব্লক উঠে যাবে)।")
                .setNegativeButton("না", null)
                .setPositiveButton("বন্ধ করুন", (d, w) ->
                        ref.child("enabled").setValue(false).addOnCompleteListener(t -> {
                            if (!t.isSuccessful()) showRulesHelp();
                            else toast("আপডেট বন্ধ করা হয়েছে");
                        }))
                .show();
    }

    private void showRulesHelp() {
        FirebaseUser u = auth.getCurrentUser();
        String uid = u == null ? "" : u.getUid();
        new AlertDialog.Builder(this)
                .setTitle("Firebase rules দরকার")
                .setMessage("Realtime Database → Rules এ app_update নোডে এই UID-কে লেখার অনুমতি দিন:\n\n"
                        + uid + "\n\n(প্রজেক্টের firebase-rules ফোল্ডারে snippet আছে)")
                .setPositiveButton("UID কপি", (d, w) -> {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("uid", uid));
                })
                .setNegativeButton("ঠিক আছে", null)
                .show();
    }

    // =========================================================================
    // helpers
    // =========================================================================

    private void fail(String msg) {
        setBusy(false);
        bar.setVisibility(View.GONE);
        setStatus(msg, RED);
    }

    private void setBusy(boolean b) {
        busy = b;
        if (btnPublish != null) {
            btnPublish.setEnabled(!b);
            btnPublish.setAlpha(b ? 0.55f : 1f);
        }
        if (btnPick != null) {
            btnPick.setEnabled(!b);
            btnPick.setAlpha(b ? 0.55f : 1f);
        }
    }

    private void setStatus(String s, int color) {
        if (status == null) return;
        status.setText(s);
        status.setTextColor(color);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private static long asLong(Object o) {
        if (o instanceof Number) return ((Number) o).longValue();
        try { return Long.parseLong(String.valueOf(o).trim()); } catch (Exception e) { return 0; }
    }

    private static String asStr(Object o) {
        return o == null ? "" : String.valueOf(o).trim();
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private LinearLayout.LayoutParams lp(int w, int h, int topDp, int unused) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(topDp);
        return p;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(16), dp(16), dp(16));
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(16));
        g.setStroke(dp(1), LINE);
        c.setBackground(g);
        return c;
    }

    private EditText field(String hint, int inputType) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(inputType);
        e.setTextSize(15);
        e.setTextColor(INK);
        e.setHintTextColor(Color.parseColor("#9A9A9A"));
        e.setPadding(dp(14), dp(10), dp(14), dp(10));
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.WHITE);
        g.setCornerRadius(dp(12));
        g.setStroke(dp(1), LINE);
        e.setBackground(g);
        return e;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(primary ? Color.WHITE : INK);
        GradientDrawable g = new GradientDrawable();
        g.setColor(primary ? INK : Color.WHITE);
        g.setCornerRadius(dp(24));
        if (!primary) g.setStroke(dp(1), LINE);
        b.setBackground(g);
        b.setStateListAnimator(null);
        return b;
    }
}
