# no special rules needed (minify is off)
